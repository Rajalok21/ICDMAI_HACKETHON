import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Color (for the line)
hex1 = "#1f77b4"  # Customize as per your preference

# Filter data for churn == 1
df_churn_1 = df[df['Churn'] == 1].copy()

# Create bins for Last Interaction, divided by 5 intervals (0-50)
bins = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50]
labels = ['0-5', '5-10', '10-15', '15-20', '20-25', '25-30', '30-35', '35-40', '40-45', '45-50']

# Bin the Last Interaction data into these ranges
df_churn_1['Last_Interaction_group'] = pd.cut(df_churn_1['Last Interaction'], bins=bins, labels=labels, right=False)

# Count the number of entries in each Last Interaction group
last_interaction_group_counts = df_churn_1['Last_Interaction_group'].value_counts().sort_index()

# ---- Graph: Last Interaction vs Churn (Grouped by Interaction Ranges) ----
fig_last_interaction_vs_churn = go.Figure(data=[ 
    go.Scatter(
        x=last_interaction_group_counts.index,  # The last interaction groups
        y=last_interaction_group_counts.values,  # The counts for each interaction group
        mode='lines+markers',  # Line graph with markers
        line=dict(color=hex1),  # Apply hex1 color for the line
        marker=dict(color=hex1)  # Apply hex1 color for the markers
    )
])

# Update layout for better visualization
fig_last_interaction_vs_churn.update_layout(
    title="Last Interaction vs Churn",
    xaxis_title="Last Interaction Group",
    yaxis_title="Count"
)

# Save the line graph as an HTML file
fig_last_interaction_vs_churn.write_html("assets/last_interaction_vs_churn.html")
