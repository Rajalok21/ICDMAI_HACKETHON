import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Colors (example)
hex1 = "#1f77b4"  # Customize as per your preference for male
hex2 = "#ff7f0e"  # Customize as per your preference for female

# Filter data for churn == 1 (using capitalized 'Churn' column)
df_churn_1 = df[df['Churn'] == 1]

# Count gender distribution in churned users (using capitalized 'Gender' column)
gender_churn_counts = df_churn_1['Gender'].value_counts()

# Ensure the order is Male first, Female second (or vice versa)
gender_churn_counts = gender_churn_counts.reindex(['Male', 'Female'], fillvalue=0)

# ---- Graph: Gender vs Churn (Pie Chart) ----
fig_gender_vs_churn = go.Figure(data=[
    go.Pie(
        labels=gender_churn_counts.index,  # Male, Female
        values=gender_churn_counts.values,  # Count of churned users for each gender
        marker=dict(
            colors=[hex1, hex2]  # Use hex1 for male and hex2 for female
        ),
        textinfo='label+percent',  # Show label and percentage on the pie chart
        title="Gender vs Churn",  # Title of the pie chart
    )
])

# Save the pie chart as an HTML file
fig_gender_vs_churn.write_html("assets/gender_vs_churn.html")
