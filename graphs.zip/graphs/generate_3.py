import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Color (example)
hex1 = "#1f77b4"  # Customize as per your preference

# Filter data for churn == 1
df_churn_1 = df[df['Churn'] == 1].copy()

# Create bins for Tenure with intervals of 10 (including 70-80 range)
tenure_bins = [0, 10, 20, 30, 40, 50, 60, 70, 80]  # Updated tenure ranges
tenure_labels = ['0-10', '10-20', '20-30', '30-40', '40-50', '50-60', '60-70', '70-80']  # Updated labels

# Bin the tenure data into these ranges
df_churn_1['Tenure_group'] = pd.cut(df_churn_1['Tenure'], bins=tenure_bins, labels=tenure_labels, right=False)

# Count the number of entries in each tenure group
tenure_group_counts = df_churn_1['Tenure_group'].value_counts().sort_index()

# ---- Graph: Tenure vs Churn (Grouped by Tenure Ranges) ----
fig_tenure_vs_churn = go.Figure(data=[ 
    go.Bar(
        x=tenure_group_counts.values,  # The counts for each tenure group
        y=tenure_group_counts.index,  # The tenure group labels
        orientation='h',  # Horizontal bars
        marker_color=hex1,  # Apply hex1 color for all bars
    )
])

# Update layout for better visualization
fig_tenure_vs_churn.update_layout(
    title="Tenure vs Churn",
    xaxis_title="Count",
    yaxis_title="Tenure Group"
)

# Save the bar graph as an HTML file
fig_tenure_vs_churn.write_html("assets/tenure_vs_churn.html")
