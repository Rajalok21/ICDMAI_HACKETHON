import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Color (example)
hex1 = "#1f77b4"  # Customize as per your preference

# Filter data for churn == 1
df_churn_1 = df[df['Churn'] == 1].copy()

# Count the number of entries for each support call value (0-10)
support_call_counts = df_churn_1['Support Calls'].value_counts().sort_index()

# ---- Graph: Support Calls vs Churn (Line Graph) ----
fig_support_calls_vs_churn = go.Figure(data=[ 
    go.Scatter(
        x=support_call_counts.index,  # The number of support calls (0-10)
        y=support_call_counts.values,  # The count of churn entries for each support call value
        mode='lines+markers',  # Line graph with markers for each point
        line=dict(color=hex1),  # Set the color of the line
        marker=dict(color=hex1),  # Set the color of the markers
    )
])

# Update layout for better visualization
fig_support_calls_vs_churn.update_layout(
    title="Support Calls vs Churn",
    xaxis_title="Number of Support Calls",
    yaxis_title="Count of Churn",
)

# Save the line graph as an HTML file
fig_support_calls_vs_churn.write_html("assets/support_calls_vs_churn.html")
