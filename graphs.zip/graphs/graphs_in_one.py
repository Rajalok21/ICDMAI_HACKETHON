import dash
from dash import dcc, html
import plotly.graph_objects as go
import pandas as pd

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the hex colors to be used for the graphs (as passed parameters)
hex1 = "#1f77b4"  # Primary color
hex2 = "#ff7f0e"  # Secondary color
hex3 = "#2ca02c"  # Third color for pie chart divisions

# Example: Age vs Churn (Placeholder for graph)
# Here, we'll assume the graph will be added as an HTML file later
# The graph will be saved in the assets folder as 'age_vs_churn.html'

# Layout for the dashboard
app.layout = html.Div(
    children=[
        html.H1("Churn Analysis Dashboard", style={"textAlign": "center"}),

        # Container for the 'Age vs Churn' graph
        html.Div(
            children=[
                html.H3("Age vs Churn"),
                html.Iframe(
                    src='/assets/age_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Gender vs Churn' graph (Pie chart)
        html.Div(
            children=[
                html.H3("Gender vs Churn"),
                html.Iframe(
                    src='/assets/gender_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Tenure vs Churn' graph
        html.Div(
            children=[
                html.H3("Tenure vs Churn"),
                html.Iframe(
                    src='/assets/tenure_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Usage Frequency vs Churn' graph
        html.Div(
            children=[
                html.H3("Usage Frequency vs Churn"),
                html.Iframe(
                    src='/assets/usage_frequency_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Support Calls Made vs Churn' graph
        html.Div(
            children=[
                html.H3("Support Calls Made vs Churn"),
                html.Iframe(
                    src='/assets/support_calls_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Payment Delay vs Churn' graph
        html.Div(
            children=[
                html.H3("Payment Delay vs Churn"),
                html.Iframe(
                    src='/assets/payment_delay_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Subscription Type vs Churn' graph (Pie chart)
        html.Div(
            children=[
                html.H3("Subscription Type vs Churn"),
                html.Iframe(
                    src='/assets/subscription_type_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Contract Length vs Churn' graph (Pie chart)
        html.Div(
            children=[
                html.H3("Contract Length vs Churn"),
                html.Iframe(
                    src='/assets/contract_length_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Total Spend vs Churn' graph
        html.Div(
            children=[
                html.H3("Total Spend vs Churn"),
                html.Iframe(
                    src='/assets/total_spend_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),

        # Container for the 'Last Interaction vs Churn' graph
        html.Div(
            children=[
                html.H3("Last Interaction vs Churn"),
                html.Iframe(
                    src='/assets/last_interaction_vs_churn.html',  # Placeholder for the actual graph
                    width='100%',
                    height='600'
                ),
            ],
            style={"padding": "20px"}
        ),
    ]
)

# Run the Dash app
if __name__ == "__main__":
    app.run_server(debug=True)
