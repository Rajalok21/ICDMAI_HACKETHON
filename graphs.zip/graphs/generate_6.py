import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Color (example)
hex1 = "#1f77b4"  # Customize as per your preference

# Filter data for churn == 1
df_churn_1 = df[df['Churn'] == 1].copy()

# Create payment delay bins (0-5, 5-10, ..., 50-55)
bins = list(range(0, 56, 5))
labels = [f"{i}-{i+5}" for i in bins[:-1]]  # Label each bin as '0-5', '5-10', ..., '50-55'

# Bin the payment delay data into these ranges
df_churn_1['Payment_delay_group'] = pd.cut(df_churn_1['Payment Delay'], bins=bins, labels=labels, right=False)

# Count the number of entries in each payment delay group
payment_delay_counts = df_churn_1['Payment_delay_group'].value_counts().sort_index()

# ---- Graph: Payment Delay vs Churn (Line Graph) ----
fig_payment_delay_vs_churn = go.Figure(data=[ 
    go.Scatter(
        x=payment_delay_counts.index,  # The payment delay groups (e.g., 0-5, 5-10, ..., 50-55)
        y=payment_delay_counts.values,  # The count of churn entries for each payment delay group
        mode='lines+markers',  # Line graph with markers for each point
        line=dict(color=hex1),  # Set the color of the line
        marker=dict(color=hex1),  # Set the color of the markers
    )
])

# Update layout for better visualization
fig_payment_delay_vs_churn.update_layout(
    title="Payment Delay vs Churn",
    xaxis_title="Payment Delay Group",
    yaxis_title="Count of Churn",
)

# Save the line graph as an HTML file
fig_payment_delay_vs_churn.write_html("assets/payment_delay_vs_churn.html")
