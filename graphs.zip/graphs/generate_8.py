import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Colors (using hex1, hex2, hex3 as done in previous graphs)
hex1 = "#1f77b4"  # Monthly contract
hex2 = "#ff7f0e"  # Quarterly contract
hex3 = "#2ca02c"  # Annually contract

# Filter data for churn == 1
df_churn_1 = df[df['Churn'] == 1].copy()

# Count the number of churns for each contract length category
contract_length_counts = df_churn_1['Contract Length'].value_counts()

# ---- Graph: Contract Length vs Churn (Pie Chart) ----
fig_contract_length_vs_churn = go.Figure(data=[ 
    go.Pie(
        labels=contract_length_counts.index,  # Labels for Contract Length categories (Monthly, Quarterly, Annually)
        values=contract_length_counts.values,  # Churn counts for each category
        marker=dict(colors=[hex1, hex2, hex3]),  # Apply colors for each category
    )
])

# Update layout for better visualization
fig_contract_length_vs_churn.update_layout(
    title="Contract Length vs Churn",
)

# Save the pie graph as an HTML file
fig_contract_length_vs_churn.write_html("assets/contract_length_vs_churn.html")
