import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Color (for the bars)
hex1 = "#1f77b4"  # Customize as per your preference

# Filter data for churn == 1
df_churn_1 = df[df['Churn'] == 1].copy()

# Create bins for Total Spend, divided by 100 intervals
bins = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]
labels = ['100-200', '200-300', '300-400', '400-500', '500-600', '600-700', '700-800', '800-900', '900-1000']

# Bin the Total Spend data into these ranges
df_churn_1['Total_Spend_group'] = pd.cut(df_churn_1['Total Spend'], bins=bins, labels=labels, right=False)

# Count the number of entries in each spend group
total_spend_group_counts = df_churn_1['Total_Spend_group'].value_counts().sort_index()

# ---- Graph: Total Spend vs Churn (Grouped by Spend Ranges) ----
fig_total_spend_vs_churn = go.Figure(data=[ 
    go.Bar(
        x=total_spend_group_counts.values,  # The counts for each total spend group
        y=total_spend_group_counts.index,  # The total spend group labels
        orientation='h',  # Horizontal bars
        marker_color=hex1,  # Apply hex1 color for all bars
    )
])

# Update layout for better visualization
fig_total_spend_vs_churn.update_layout(
    title="Total Spend vs Churn",
    xaxis_title="Count",
    yaxis_title="Total Spend Group"
)

# Save the bar graph as an HTML file
fig_total_spend_vs_churn.write_html("assets/total_spend_vs_churn.html")
