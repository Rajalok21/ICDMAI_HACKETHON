import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Color (example)
hex1 = "#1f77b4"  # Customize as per your preference

# Filter data for churn == 1
df_churn_1 = df[df['Churn'] == 1].copy()

# Create usage frequency bins (0-5, 5-10, ..., 50-55)
bins = list(range(0, 56, 5))  # Creating bins from 0 to 50 with an interval of 5
labels = [f"{i}-{i+5}" for i in bins[:-1]]  # Label each bin as '0-5', '5-10', ..., '50-55'

# Bin the usage frequency data into these ranges
df_churn_1['Usage_frequency_group'] = pd.cut(df_churn_1['Usage Frequency'], bins=bins, labels=labels, right=False)

# Count the number of entries in each usage frequency group
usage_frequency_counts = df_churn_1['Usage_frequency_group'].value_counts().sort_index()

# ---- Graph: Usage Frequency vs Churn (Line Graph) ----
fig_usage_frequency_vs_churn = go.Figure(data=[ 
    go.Scatter(
        x=usage_frequency_counts.index,  # The usage frequency groups (e.g., 0-5, 5-10, ..., 50-55)
        y=usage_frequency_counts.values,  # The count of churn entries for each usage frequency group
        mode='lines+markers',  # Line graph with markers for each point
        line=dict(color=hex1),  # Set the color of the line
        marker=dict(color=hex1),  # Set the color of the markers
    )
])

# Update layout for better visualization
fig_usage_frequency_vs_churn.update_layout(
    title="Usage Frequency vs Churn",
    xaxis_title="Usage Frequency Group",
    yaxis_title="Count of Churn",
)

# Save the line graph as an HTML file
fig_usage_frequency_vs_churn.write_html("assets/usage_frequency_vs_churn.html")
