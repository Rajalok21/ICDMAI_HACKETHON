import pandas as pd
import plotly.graph_objects as go

# Load dataset
df = pd.read_csv("original_dataset.csv")

# Define Hex Colors (using hex1, hex2, hex3 as done in the Gender vs Churn graph)
hex1 = "#1f77b4"  # Basic Subscription
hex2 = "#ff7f0e"  # Premium Subscription
hex3 = "#2ca02c"  # Standard Subscription

# Filter data for churn == 1
df_churn_1 = df[df['Churn'] == 1].copy()

# Count churn occurrences per subscription type
subscription_counts = df_churn_1['Subscription Type'].value_counts()

# ---- Graph: Subscription Type vs Churn (Pie Chart) ----
fig_subscription_vs_churn = go.Figure(data=[ 
    go.Pie(
        labels=subscription_counts.index,  # Subscription types (Basic, Premium, Standard)
        values=subscription_counts.values,  # Count of churn for each subscription type
        marker=dict(colors=[hex1, hex2, hex3]),  # Assign colors to the slices
    )
])

# Update layout for better visualization
fig_subscription_vs_churn.update_layout(
    title="Subscription Type vs Churn",
)

# Save the pie graph as an HTML file
fig_subscription_vs_churn.write_html("assets/subscription_type_vs_churn.html")
